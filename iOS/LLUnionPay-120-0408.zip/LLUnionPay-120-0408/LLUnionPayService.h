#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef enum LLPayResult {
    kLLPayResultSuccess = 0,    // 支付成功
    kLLPayResultFail = 1,       // 支付失败
    kLLPayResultCancel = 2,     // 支付取消，用户行为
    kLLPayResultInitError = 3,      // 支付初始化错误，订单信息有误，签名失败等
    kLLPayResultInitParamError = 4, // 支付订单参数有误，无法进行初始化，未传必要信息等
    kLLPayResultUnknow = 5,         // 其他
    kLLPayResultRequestingCancel,//授权支付后取消(支付请求已发送)
}LLPayResult;


typedef void(^CompletionHandler)(LLPayResult result, NSDictionary *dic);

@interface LLPayService  : NSObject {
    UIViewController        *presentController;
    BOOL                    enableDebugInfo;
}


@property (nonatomic, copy) CompletionHandler completionHandler;
/**
 *  单例sdk
 *
 *  @return 返回LLPaySdk的单例对象
 */
+ (instancetype)sharedSdk;

/**
 SDK 默认由 window.rootVC present, 若已占用,请自定义
 */
@property (nonatomic, strong, nullable) UIViewController *cusViewController;

- (void)llSDKInit:(NSString *_Nullable)language style:(NSString *_Nullable)style   complete:(CompletionHandler _Nullable )complete;

- (void)llResetPassword:(NSString *_Nullable)paymentInfo   complete:(CompletionHandler _Nullable )complete;

- (void)llSetNewPassword:(NSString *_Nullable)paymentInfo   complete:(CompletionHandler _Nullable)complete;
//
- (void)llForgetPassword:(NSString *_Nullable)paymentInfo   complete:(CompletionHandler _Nullable)complete;

- (void)llUnionPayWithPaymentInfo:(NSString *_Nullable)paymentInfo  complete:(CompletionHandler _Nullable)complete;

- (void)llUnionPayByQRCode:(NSString *_Nullable)paymentInfo acctId:(NSString *_Nullable)acctId complete:(CompletionHandler _Nullable)complete ;


///**
// 切换正式、测试服务器（默认不调用是正式环境，请不要随意使用该函数切换至测试环境）
//
// @param isTestServer isTestServer YES测试环境，NO正式环境
// */
+ (void)switchToTestServer:(BOOL)isTestServer  testType:(NSString *_Nullable)type;


@end
