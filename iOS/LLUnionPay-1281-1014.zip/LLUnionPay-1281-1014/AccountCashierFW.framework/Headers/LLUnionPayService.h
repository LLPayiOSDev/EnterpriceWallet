#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef enum LLPayResult {
    kLLPayResultSuccess = 0,    // 支付成功
    kLLPayResultFail = 1,       // 支付失败
    kLLPayResultCancel = 2,     // 支付取消，用户行为
    kLLPayResultInitError = 3,      // 支付初始化错误，订单信息有误，签名失败等
    kLLPayResultInitParamError = 4, // 支付订单参数有误，无法进行初始化，未传必要信息等
    kLLPayResultUnknow = 5,  // 支付订单参数有误，无法进行初始化，未传必要信息等
    kLLPayResultTimeOut = 6,          // 其他
    kLLPayResultRequestingCancel,//授权支付后取消(支付请求已发送)
}LLPayResult;

typedef enum LLServiceType {
    SET_NEW_PWD = 20,    // 新密码
    RESET_PWD = 21,       // 重制密码
    FORGET_PWD = 22,     // 忘记密码
    PAY_BY_SCAN_CODE = 23,      // 主扫支付，一般不用。
    PAY = 24, // 支付
}LLServiceType;

typedef enum LLShowSDKAbility {
    SCAN_PAY = 10,    // 主扫
    CODE_PAY = 11,       // 被扫
    CARD_MANAGE = 12,     // 卡管理
    TRADE_RECORD = 13,     // 卡管理
}LLShowSDKAbility;

typedef void(^CompletionHandler)(LLPayResult result, NSDictionary * _Nullable dic);

__attribute__((visibility("default")))
@interface LLPayService  : NSObject {
    UIViewController        *presentController;
    BOOL                    enableDebugInfo;
}


@property (nonatomic, copy) CompletionHandler _Nullable completionHandler;
/**
 *  单例sdk
 *
 *  @return 返回LLPaySdk的单例对象
 */
+ (instancetype _Nullable )sharedSdk;

/**
 SDK 默认由 window.rootVC present, 若已占用,请自定义
 */
@property (nonatomic, strong, nullable) UIViewController *cusViewController;

- (void)llSDKInit:(NSString *_Nullable)language style:(NSString *_Nullable)style   showSDKAbilityList:(NSMutableArray<NSNumber *>* _Nullable )showSDKAbilityList mainViewColor:(NSString *_Nullable)mainViewColor needPayResultController:(BOOL)need complete:(CompletionHandler _Nullable )complete;

- (void)llSDKInit:(NSString *_Nullable)language style:(NSString *_Nullable)style   showSDKAbilityList:(NSMutableArray<NSNumber *>* _Nullable )showSDKAbilityList mainViewColor:(NSString *_Nullable)mainViewColor complete:(CompletionHandler _Nullable )complete;

- (void)llOpenSDKWithServiceType:(NSString *_Nullable)paymentInfo acctId:(NSString *_Nullable)acctId
                     serviceType:(LLServiceType )serviceType  limitAccountNos:(NSArray<NSString *> *_Nullable)limitAccountNos complete:(CompletionHandler _Nullable)complete;

- (void)llOpenSDKWithServiceType:(NSString *_Nullable)paymentInfo acctId:(NSString *_Nullable)acctId  serviceType:(LLServiceType )serviceType complete:(CompletionHandler _Nullable)complete;
//
//- (void)llResetPassword:(NSString *_Nullable)paymentInfo   complete:(CompletionHandler _Nullable )complete;
//
//- (void)llSetNewPassword:(NSString *_Nullable)paymentInfo   complete:(CompletionHandler _Nullable)complete;
////
//- (void)llForgetPassword:(NSString *_Nullable)paymentInfo   complete:(CompletionHandler _Nullable)complete;
//
//- (void)llUnionPayWithPaymentInfo:(NSString *_Nullable)paymentInfo  complete:(CompletionHandler _Nullable)complete;
//
//- (void)llUnionPayByQRCode:(NSString *_Nullable)paymentInfo acctId:(NSString *_Nullable)acctId complete:(CompletionHandler _Nullable)complete ;


///**
// 切换正式、测试服务器（默认不调用是正式环境，请不要随意使用该函数切换至测试环境）
//
// @param isTestServer isTestServer YES测试环境，NO正式环境
// */
+ (void)switchToTestServer:(BOOL)isTestServer  testType:(NSString *_Nullable)type;


@end
