//
//  AppDelegate.m
//  AccountCashierDemo
//
//  Created by lliOS on 2020/10/19.
//  Copyright © 2020 lliOS. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
//    if (@available(iOS 13.0, *)) {
//
//      } else {
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
          
    // Override point for customization after application launch.
//    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    ViewController *view = [story instantiateViewControllerWithIdentifier:@"ViewController"];
//    ViewController *viewController = [[ViewController alloc] init];
    self.window.rootViewController = view;
          
    [self.window makeKeyAndVisible];
//      }
    return YES;
}


@end
