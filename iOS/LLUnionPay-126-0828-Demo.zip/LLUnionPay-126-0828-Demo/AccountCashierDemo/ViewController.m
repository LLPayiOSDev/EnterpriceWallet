//
//  ViewController.m
//  AccountCashierDemo
//
//  Created by lliOS on 2020/10/19.
//  Copyright © 2020 lliOS. All rights reserved.
//

#import "ViewController.h"
#import "Lib/LLUnionPayService.h"

@interface ViewController ()<UITextFieldDelegate> {
    __weak IBOutlet UITextField *signatureTextField;
    __weak IBOutlet UITextField *requestDataTextField;
    
    __weak IBOutlet UITextField *acctIdTextField;
    __weak IBOutlet UITextField *sdkInitTextField;
    __weak IBOutlet UITextField *styleTextField;
    __weak IBOutlet UITextField *colorTextField;
    __weak IBOutlet UITextField *typeTextField;
    __weak IBOutlet UIButton *sureBtn;
}

@end

@implementation ViewController
- (UIStatusBarStyle)preferredStatusBarStyle {
    NSLog(@"ViewController===%@",@"UIStatusBarStyleDarkContent" );
    return UIStatusBarStyleLightContent; // 返回需要的状态栏样式
}
- (void)viewDidLoad {//
    [super viewDidLoad];
    signatureTextField.text = @"1";
    acctIdTextField.text = @"";
    
    requestDataTextField.text = @"9941122e0cbb4512aef7eed3c5dafc22";
//        [[LLPayService sharedSdk] llSDKInit:@"zh_CN"  style:@"STYLES_HAINAN_PAY" complete:NULL];
    

    [[LLPayService sharedSdk] llSDKInit:@"zh_CN"  style:@"STYLES_DEFAULT_PAY" showSDKAbilityList:NULL mainViewColor:NULL complete:NULL];
//    - (void)llSDKInit:(NSString *_Nullable)language style:(NSString *_Nullable)style   complete:(CompletionHandler _Nullable )complete;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
     [self.view endEditing:YES];
}
- (void)backToOrderWithResult:(LLPayResult)resultCode withDic:(NSDictionary*)resultDic{
    
}


//点击
- (IBAction)sdkInitClick:(id)sender {
    if (sdkInitTextField.text.length == 0) {
       //        [XHToast showCenterWithText:@"报文不能为空！" duration:1.5];
       return;
    }  else {
        NSMutableArray<NSNumber *> *showSDKAbilityLis =[NSMutableArray array];
        if(typeTextField!=NULL&&[typeTextField.text rangeOfString:@"1"].location != NSNotFound){
            [showSDKAbilityLis addObject:@10];
        }
        if(typeTextField!=NULL&&[typeTextField.text rangeOfString:@"2"].location != NSNotFound){
            
                [showSDKAbilityLis addObject:@11];
        }
        if(typeTextField!=NULL&&[typeTextField.text rangeOfString:@"3"].location != NSNotFound){
            
                [showSDKAbilityLis addObject:@12];
        }
        if(typeTextField!=NULL&&[typeTextField.text rangeOfString:@"4"].location != NSNotFound){
            
                [showSDKAbilityLis addObject:@13];
        }
        [[LLPayService sharedSdk] llSDKInit:@"zh_CN"  style:@"STYLES_DEFAULT_PAY" showSDKAbilityList:NULL mainViewColor:NULL  complete:NULL];
    }
}



//点击
- (IBAction)payByQRCodeClick:(id)sender {
    
    
     if (requestDataTextField.text.length == 0) {
        //        [XHToast showCenterWithText:@"报文不能为空！" duration:1.5];
        return;
    }  else {
        if([signatureTextField.text isEqual:@"2"]||[signatureTextField.text isEqual:@"1"]||[signatureTextField.text isEqual:@"3"]||[signatureTextField.text isEqual:@"4"]){
            [LLPayService switchToTestServer:YES testType:signatureTextField.text];
        }else{
            [LLPayService switchToTestServer:NO testType:signatureTextField.text];
        }
        //
        
        [[LLPayService sharedSdk]llOpenSDKWithServiceType:requestDataTextField.text acctId:acctIdTextField.text  serviceType:PAY complete:^(LLPayResult result, NSDictionary *dic){
//        [[LLPayService sharedSdk]llUnionPayByQRCode:requestDataTextField.text   acctId:acctIdTextField.text complete:^(LLPayResult result, NSDictionary *dic){
            //商户自行查单
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:0 error:0];
            NSString *dataStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            NSLog(@"-------%@",dic);
            UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"返回提示" message:dataStr preferredStyle:UIAlertControllerStyleActionSheet];
            //默认只有标题 没有操作的按钮:添加操作的按钮 UIAlertAction

            UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                NSLog(@"取消");
            }];
            [alertVc addAction:cancelBtn];
            //展示
            [self presentViewController:alertVc animated:YES completion:nil];
        }];
    }
    
}
    
//点击
- (IBAction)sendDidClick:(id)sender {
    if (requestDataTextField.text.length == 0) {
//        [XHToast showCenterWithText:@"报文不能为空！" duration:1.5];
         return;
    }  else {
        if([signatureTextField.text isEqual:@"2"]||[signatureTextField.text isEqual:@"1"]||[signatureTextField.text isEqual:@"3"]||[signatureTextField.text isEqual:@"4"]){
            [LLPayService switchToTestServer:YES testType:signatureTextField.text];
        }else{
            [LLPayService switchToTestServer:NO testType:signatureTextField.text];
        }
        
        [[LLPayService sharedSdk]llOpenSDKWithServiceType:requestDataTextField.text acctId:@""  serviceType:PAY_BY_SCAN_CODE complete:^(LLPayResult result, NSDictionary *dic){
//        [[LLPayService sharedSdk]llUnionPayWithPaymentInfo:requestDataTextField.text complete:^(LLPayResult result, NSDictionary *dic){
            //商户自行查单
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:0 error:0];
            NSString *dataStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            NSLog(@"-------%@",dic);
            UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"返回提示" message:dataStr preferredStyle:UIAlertControllerStyleActionSheet];
               //默认只有标题 没有操作的按钮:添加操作的按钮 UIAlertAction

               UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                   NSLog(@"取消");
               }];
               [alertVc addAction:cancelBtn];
               //展示
               [self presentViewController:alertVc animated:YES completion:nil];
        }];
//
        
    }
}

- (IBAction)forgetPWDPWDClick:(id)sender {
    if (requestDataTextField.text.length == 0) {
        //        [XHToast showCenterWithText:@"报文不能为空！" duration:1.5];
        return;
    }   else {
        if([signatureTextField.text isEqual:@"2"]||[signatureTextField.text isEqual:@"1"]||[signatureTextField.text isEqual:@"3"]||[signatureTextField.text isEqual:@"4"]){
            [LLPayService switchToTestServer:YES testType:signatureTextField.text];
        }else{
            [LLPayService switchToTestServer:NO testType:signatureTextField.text];
        }
        [[LLPayService sharedSdk]llOpenSDKWithServiceType:requestDataTextField.text acctId:@""  serviceType:FORGET_PWD complete:^(LLPayResult result, NSDictionary *dic){
//        [[LLPayService sharedSdk]llForgetPassword:requestDataTextField.text complete:^(LLPayResult result, NSDictionary *dic){
            //商户自行查单
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:0 error:0];
            NSString *dataStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
              NSLog(@"-------%@",dic);
              UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"返回提示" message:dataStr preferredStyle:UIAlertControllerStyleActionSheet];
                 //默认只有标题 没有操作的按钮:添加操作的按钮 UIAlertAction
                 
                 UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                     NSLog(@"取消");
                 }];
                 [alertVc addAction:cancelBtn];
                 //展示
                 [self presentViewController:alertVc animated:YES completion:nil];
          }];
      }
}
//点击
- (IBAction)setNewPWDClick:(id)sender {
  if (requestDataTextField.text.length == 0) {
//        [XHToast showCenterWithText:@"报文不能为空！" duration:1.5];
         return;
    }  else {
        if([signatureTextField.text isEqual:@"2"]||[signatureTextField.text isEqual:@"1"]||[signatureTextField.text isEqual:@"3"]||[signatureTextField.text isEqual:@"4"]){
            [LLPayService switchToTestServer:YES testType:signatureTextField.text];
        }else{
            [LLPayService switchToTestServer:NO testType:signatureTextField.text];
        }
        [[LLPayService sharedSdk]llOpenSDKWithServiceType:requestDataTextField.text acctId:@""  serviceType:SET_NEW_PWD complete:^(LLPayResult result, NSDictionary *dic){
//        [[LLPayService sharedSdk]llSetNewPassword:requestDataTextField.text complete:^(LLPayResult result, NSDictionary *dic){
            //商户自行查单
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:0 error:0];
            NSString *dataStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            NSLog(@"-------%@",dic);
            UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"返回提示" message:dataStr preferredStyle:UIAlertControllerStyleActionSheet];
               //默认只有标题 没有操作的按钮:添加操作的按钮 UIAlertAction
               
               UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                   NSLog(@"取消");
               }];
               [alertVc addAction:cancelBtn];
               //展示
               [self presentViewController:alertVc animated:YES completion:nil];
        }];
    }
}


//点击
- (IBAction)resetPWDClick:(id)sender {
    if (requestDataTextField.text.length == 0) {
//        [XHToast showCenterWithText:@"报文不能为空！" duration:1.5];
         return;
    }  else {
        if([signatureTextField.text isEqual:@"2"]||[signatureTextField.text isEqual:@"1"]||[signatureTextField.text isEqual:@"3"]||[signatureTextField.text isEqual:@"4"]){
            [LLPayService switchToTestServer:YES testType:signatureTextField.text];
        }else{
            [LLPayService switchToTestServer:NO testType:signatureTextField.text];
        }
        
        [[LLPayService sharedSdk]llOpenSDKWithServiceType:requestDataTextField.text acctId:@""  serviceType:RESET_PWD complete:^(LLPayResult result, NSDictionary *dic){
//        [[LLPayService sharedSdk]llResetPassword:requestDataTextField.text complete:^(LLPayResult result, NSDictionary *dic){
            //商户自行查单
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:0 error:0];
            NSString *dataStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            NSLog(@"-------%@",dic);
            UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"返回提示" message:dataStr preferredStyle:UIAlertControllerStyleActionSheet];
               //默认只有标题 没有操作的按钮:添加操作的按钮 UIAlertAction
               
               UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                   NSLog(@"取消");
               }];
               [alertVc addAction:cancelBtn];
               //展示
               [self presentViewController:alertVc animated:YES completion:nil];
        }];
    }
}
@end
