//
//  AppDelegate.h
//  AccountCashierDemo
//
//  Created by lliOS on 2020/10/19.
//  Copyright © 2020 lliOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow * window;



@end

