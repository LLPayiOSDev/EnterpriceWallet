////
////  SceneDelegate.h
////  AccountCashierDemo
////
////  Created by lliOS on 2020/10/19.
////  Copyright © 2020 lliOS. All rights reserved.
////
//
//#import <UIKit/UIKit.h>
//
//@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>
//
//@property (strong, nonatomic) UIWindow * window;
//
//@end
//
